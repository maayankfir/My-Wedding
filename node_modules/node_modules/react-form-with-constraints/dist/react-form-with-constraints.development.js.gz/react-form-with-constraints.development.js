(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('react'), require('prop-types')) :
    typeof define === 'function' && define.amd ? define(['exports', 'react', 'prop-types'], factory) :
    (global = global || self, factory(global.ReactFormWithConstraints = {}, global.React, global.PropTypes));
}(this, function (exports, React, PropTypes) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) if (e.indexOf(p[i]) < 0)
                t[p[i]] = s[p[i]];
        return t;
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __values(o) {
        var m = typeof Symbol === "function" && o[Symbol.iterator], i = 0;
        if (m) return m.call(o);
        return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    var EventEmitter = (function () {
        function EventEmitter() {
            this.listeners = new Map();
        }
        EventEmitter.prototype.emit = function (eventName) {
            var args = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                args[_i - 1] = arguments[_i];
            }
            return __awaiter(this, void 0, void 0, function () {
                var e_1, _a, listeners, ret, listeners_1, listeners_1_1, listener, _b, _c, e_1_1;
                return __generator(this, function (_d) {
                    switch (_d.label) {
                        case 0:
                            listeners = this.listeners.get(eventName);
                            ret = new Array();
                            if (!(listeners !== undefined)) return [3, 8];
                            console.assert(listeners.length > 0, "No listener for event '" + eventName + "'");
                            _d.label = 1;
                        case 1:
                            _d.trys.push([1, 6, 7, 8]);
                            listeners_1 = __values(listeners), listeners_1_1 = listeners_1.next();
                            _d.label = 2;
                        case 2:
                            if (!!listeners_1_1.done) return [3, 5];
                            listener = listeners_1_1.value;
                            _c = (_b = ret).push;
                            return [4, listener.apply(void 0, __spread(args))];
                        case 3:
                            _c.apply(_b, [_d.sent()]);
                            _d.label = 4;
                        case 4:
                            listeners_1_1 = listeners_1.next();
                            return [3, 2];
                        case 5: return [3, 8];
                        case 6:
                            e_1_1 = _d.sent();
                            e_1 = { error: e_1_1 };
                            return [3, 8];
                        case 7:
                            try {
                                if (listeners_1_1 && !listeners_1_1.done && (_a = listeners_1.return)) _a.call(listeners_1);
                            }
                            finally { if (e_1) throw e_1.error; }
                            return [7];
                        case 8: return [2, ret];
                    }
                });
            });
        };
        EventEmitter.prototype.addListener = function (eventName, listener) {
            if (!this.listeners.has(eventName))
                this.listeners.set(eventName, []);
            var listeners = this.listeners.get(eventName);
            console.assert(listeners.indexOf(listener) === -1, "Listener already added for event '" + eventName + "'");
            listeners.push(listener);
        };
        EventEmitter.prototype.removeListener = function (eventName, listener) {
            var listeners = this.listeners.get(eventName);
            console.assert(listeners !== undefined, "Unknown event '" + eventName + "'");
            var index = listeners.lastIndexOf(listener);
            console.assert(index > -1, "Listener not found for event '" + eventName + "'");
            listeners.splice(index, 1);
            if (listeners.length === 0)
                this.listeners.delete(eventName);
        };
        return EventEmitter;
    }());

    var ValidateFieldEvent = 'VALIDATE_FIELD_EVENT';
    var withValidateFieldEventEmitter = function (Base) {
        return (function (_super) {
            __extends(ValidateFieldEventEmitter, _super);
            function ValidateFieldEventEmitter() {
                var _this = _super !== null && _super.apply(this, arguments) || this;
                _this.validateFieldEventEmitter = new EventEmitter();
                return _this;
            }
            ValidateFieldEventEmitter.prototype.emitValidateFieldEvent = function (input) {
                return this.validateFieldEventEmitter.emit(ValidateFieldEvent, input);
            };
            ValidateFieldEventEmitter.prototype.addValidateFieldEventListener = function (listener) {
                this.validateFieldEventEmitter.addListener(ValidateFieldEvent, listener);
            };
            ValidateFieldEventEmitter.prototype.removeValidateFieldEventListener = function (listener) {
                this.validateFieldEventEmitter.removeListener(ValidateFieldEvent, listener);
            };
            return ValidateFieldEventEmitter;
        }(Base));
    };

    var FieldWillValidateEvent = 'FIELD_WILL_VALIDATE_EVENT';
    var withFieldWillValidateEventEmitter = function (Base) {
        return (function (_super) {
            __extends(FieldWillValidateEventEmitter, _super);
            function FieldWillValidateEventEmitter() {
                var _this = _super !== null && _super.apply(this, arguments) || this;
                _this.fieldWillValidateEventEmitter = new EventEmitter();
                return _this;
            }
            FieldWillValidateEventEmitter.prototype.emitFieldWillValidateEvent = function (fieldName) {
                return this.fieldWillValidateEventEmitter.emit(FieldWillValidateEvent, fieldName);
            };
            FieldWillValidateEventEmitter.prototype.addFieldWillValidateEventListener = function (listener) {
                this.fieldWillValidateEventEmitter.addListener(FieldWillValidateEvent, listener);
            };
            FieldWillValidateEventEmitter.prototype.removeFieldWillValidateEventListener = function (listener) {
                this.fieldWillValidateEventEmitter.removeListener(FieldWillValidateEvent, listener);
            };
            return FieldWillValidateEventEmitter;
        }(Base));
    };

    var FieldDidValidateEvent = 'FIELD_DID_VALIDATE_EVENT';
    var withFieldDidValidateEventEmitter = function (Base) {
        return (function (_super) {
            __extends(FieldDidValidateEventEmitter, _super);
            function FieldDidValidateEventEmitter() {
                var _this = _super !== null && _super.apply(this, arguments) || this;
                _this.fieldDidValidateEventEmitter = new EventEmitter();
                return _this;
            }
            FieldDidValidateEventEmitter.prototype.emitFieldDidValidateEvent = function (field) {
                return this.fieldDidValidateEventEmitter.emit(FieldDidValidateEvent, field);
            };
            FieldDidValidateEventEmitter.prototype.addFieldDidValidateEventListener = function (listener) {
                this.fieldDidValidateEventEmitter.addListener(FieldDidValidateEvent, listener);
            };
            FieldDidValidateEventEmitter.prototype.removeFieldDidValidateEventListener = function (listener) {
                this.fieldDidValidateEventEmitter.removeListener(FieldDidValidateEvent, listener);
            };
            return FieldDidValidateEventEmitter;
        }(Base));
    };

    var FieldDidResetEvent = 'FIELD_DID_RESET_EVENT';
    var withFieldDidResetEventEmitter = function (Base) {
        return (function (_super) {
            __extends(ResetFieldEvenEmitter, _super);
            function ResetFieldEvenEmitter() {
                var _this = _super !== null && _super.apply(this, arguments) || this;
                _this.fieldDidResetEventEmitter = new EventEmitter();
                return _this;
            }
            ResetFieldEvenEmitter.prototype.emitFieldDidResetEvent = function (field) {
                return this.fieldDidResetEventEmitter.emit(FieldDidResetEvent, field);
            };
            ResetFieldEvenEmitter.prototype.addFieldDidResetEventListener = function (listener) {
                this.fieldDidResetEventEmitter.addListener(FieldDidResetEvent, listener);
            };
            ResetFieldEvenEmitter.prototype.removeFieldDidResetEventListener = function (listener) {
                this.fieldDidResetEventEmitter.removeListener(FieldDidResetEvent, listener);
            };
            return ResetFieldEvenEmitter;
        }(Base));
    };

    var InputElement = (function () {
        function InputElement(input) {
            if (input.props === undefined) {
                input = input;
                this.name = input.name;
                this.type = input.type;
                this.value = input.value;
                this.validity = new IValidityState(input.validity);
                this.validationMessage = input.validationMessage;
            }
            else {
                input = input;
                this.name = input.props.name;
                this.type = undefined;
                this.value = input.props.value;
                this.validity = undefined;
                this.validationMessage = undefined;
            }
        }
        return InputElement;
    }());
    var IValidityState = (function () {
        function IValidityState(validity) {
            this.badInput = validity.badInput;
            this.customError = validity.customError;
            this.patternMismatch = validity.patternMismatch;
            this.rangeOverflow = validity.rangeOverflow;
            this.rangeUnderflow = validity.rangeUnderflow;
            this.stepMismatch = validity.stepMismatch;
            this.tooLong = validity.tooLong;
            this.tooShort = validity.tooShort;
            this.typeMismatch = validity.typeMismatch;
            this.valid = validity.valid;
            this.valueMissing = validity.valueMissing;
        }
        return IValidityState;
    }());

    var FieldFeedbackType;
    (function (FieldFeedbackType) {
        FieldFeedbackType["Error"] = "error";
        FieldFeedbackType["Warning"] = "warning";
        FieldFeedbackType["Info"] = "info";
        FieldFeedbackType["WhenValid"] = "whenValid";
    })(FieldFeedbackType || (FieldFeedbackType = {}));
    var FieldFeedbackType$1 = FieldFeedbackType;

    var clearArray = function (array) {
        while (array.length) {
            array.pop();
        }
    };

    var Field = (function () {
        function Field(name) {
            this.name = name;
            this.validations = [];
        }
        Field.prototype.addOrReplaceValidation = function (validation) {
            var i = this.validations.findIndex(function (_validation) { return _validation.key === validation.key; });
            if (i > -1)
                this.validations[i] = validation;
            else
                this.validations.push(validation);
        };
        Field.prototype.clearValidations = function () {
            clearArray(this.validations);
        };
        Field.prototype.hasFeedbacksOfType = function (type, fieldFeedbacksKey) {
            return this.validations.some(function (fieldFeedback) {
                return (fieldFeedbacksKey === undefined || fieldFeedback.key.startsWith(fieldFeedbacksKey + ".")) &&
                    fieldFeedback.type === type && fieldFeedback.show === true;
            });
        };
        Field.prototype.hasErrors = function (fieldFeedbacksKey) {
            return this.hasFeedbacksOfType(FieldFeedbackType$1.Error, fieldFeedbacksKey);
        };
        Field.prototype.hasWarnings = function (fieldFeedbacksKey) {
            return this.hasFeedbacksOfType(FieldFeedbackType$1.Warning, fieldFeedbacksKey);
        };
        Field.prototype.hasInfos = function (fieldFeedbacksKey) {
            return this.hasFeedbacksOfType(FieldFeedbackType$1.Info, fieldFeedbacksKey);
        };
        Field.prototype.hasFeedbacks = function (fieldFeedbacksKey) {
            return this.hasErrors(fieldFeedbacksKey) ||
                this.hasWarnings(fieldFeedbacksKey) ||
                this.hasInfos(fieldFeedbacksKey);
        };
        Field.prototype.isValid = function () {
            return !this.hasErrors();
        };
        return Field;
    }());

    (function (FieldEvent) {
        FieldEvent["Added"] = "FIELD_ADDED";
        FieldEvent["Removed"] = "FIELD_REMOVED";
    })(exports.FieldEvent || (exports.FieldEvent = {}));
    var FieldsStore = (function (_super) {
        __extends(FieldsStore, _super);
        function FieldsStore() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.fields = new Array();
            return _this;
        }
        FieldsStore.prototype.getField = function (fieldName) {
            var fields = this.fields.filter(function (_field) { return _field.name === fieldName; });
            return fields.length === 1 ? fields[0] : undefined;
        };
        FieldsStore.prototype.addField = function (fieldName) {
            var fields = this.fields.filter(function (_field) { return _field.name === fieldName; });
            console.assert(fields.length === 0 || fields.length === 1, "Cannot have more than 1 field matching '" + fieldName + "'");
            if (fields.length === 0) {
                var newField = new Field(fieldName);
                this.fields.push(newField);
                this.emit(exports.FieldEvent.Added, newField);
            }
        };
        FieldsStore.prototype.removeField = function (fieldName) {
            var fields = this.fields.filter(function (_field) { return _field.name === fieldName; });
            var index = this.fields.indexOf(fields[0]);
            if (index > -1) {
                this.fields.splice(index, 1);
                this.emit(exports.FieldEvent.Removed, fieldName);
            }
        };
        FieldsStore.prototype.isValid = function () {
            return this.fields.every(function (field) { return field.isValid(); });
        };
        FieldsStore.prototype.hasFeedbacks = function () {
            return this.fields.some(function (field) { return field.hasFeedbacks(); });
        };
        return FieldsStore;
    }(EventEmitter));

    var flattenDeep = function (arrayOfArrays) {
        return arrayOfArrays
            .reduce(function (prev, curr) { return prev.concat(Array.isArray(curr) ? flattenDeep(curr) : curr); }, []);
    };

    var notUndefined = function (value) { return value !== undefined; };

    var FormWithConstraintsComponent = (function (_super) {
        __extends(FormWithConstraintsComponent, _super);
        function FormWithConstraintsComponent() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return FormWithConstraintsComponent;
    }(React.Component));
    var FormWithConstraints = (function (_super) {
        __extends(FormWithConstraints, _super);
        function FormWithConstraints() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.form = null;
            _this.fieldsStore = new FieldsStore();
            _this.fieldFeedbacksKeyCounter = 0;
            return _this;
        }
        FormWithConstraints.prototype.getChildContext = function () {
            return {
                form: this
            };
        };
        FormWithConstraints.prototype.computeFieldFeedbacksKey = function () {
            return "" + this.fieldFeedbacksKeyCounter++;
        };
        FormWithConstraints.prototype.validateFields = function () {
            var inputsOrNames = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                inputsOrNames[_i] = arguments[_i];
            }
            return this._validateFields.apply(this, __spread([true], inputsOrNames));
        };
        FormWithConstraints.prototype.validateForm = function () {
            return this.validateFieldsWithoutFeedback();
        };
        FormWithConstraints.prototype.validateFieldsWithoutFeedback = function () {
            var inputsOrNames = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                inputsOrNames[_i] = arguments[_i];
            }
            return this._validateFields.apply(this, __spread([false], inputsOrNames));
        };
        FormWithConstraints.prototype._validateFields = function (forceValidateFields) {
            var inputsOrNames = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                inputsOrNames[_i - 1] = arguments[_i];
            }
            return __awaiter(this, void 0, void 0, function () {
                var e_1, _a, fields, inputs, inputs_1, inputs_1_1, input, field, e_1_1;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            fields = new Array();
                            inputs = this.normalizeInputs.apply(this, __spread(inputsOrNames));
                            _b.label = 1;
                        case 1:
                            _b.trys.push([1, 6, 7, 8]);
                            inputs_1 = __values(inputs), inputs_1_1 = inputs_1.next();
                            _b.label = 2;
                        case 2:
                            if (!!inputs_1_1.done) return [3, 5];
                            input = inputs_1_1.value;
                            return [4, this.validateField(forceValidateFields, new InputElement(input))];
                        case 3:
                            field = _b.sent();
                            if (field !== undefined)
                                fields.push(field);
                            _b.label = 4;
                        case 4:
                            inputs_1_1 = inputs_1.next();
                            return [3, 2];
                        case 5: return [3, 8];
                        case 6:
                            e_1_1 = _b.sent();
                            e_1 = { error: e_1_1 };
                            return [3, 8];
                        case 7:
                            try {
                                if (inputs_1_1 && !inputs_1_1.done && (_a = inputs_1.return)) _a.call(inputs_1);
                            }
                            finally { if (e_1) throw e_1.error; }
                            return [7];
                        case 8: return [2, fields];
                    }
                });
            });
        };
        FormWithConstraints.prototype.validateField = function (forceValidateFields, input) {
            return __awaiter(this, void 0, void 0, function () {
                var fieldName, field, arrayOfArrays;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            fieldName = input.name;
                            field = this.fieldsStore.getField(fieldName);
                            if (!(field === undefined)) return [3, 1];
                            return [3, 3];
                        case 1:
                            if (!(forceValidateFields || !field.hasFeedbacks())) return [3, 3];
                            field.clearValidations();
                            this.emitFieldWillValidateEvent(fieldName);
                            return [4, this.emitValidateFieldEvent(input)];
                        case 2:
                            arrayOfArrays = _a.sent();
                            console.assert(JSON.stringify(flattenDeep(arrayOfArrays).filter(notUndefined))
                                ===
                                    JSON.stringify(field.validations), "FieldsStore does not match emitValidateFieldEvent() result, did the user changed the input rapidly?");
                            this.emitFieldDidValidateEvent(field);
                            _a.label = 3;
                        case 3: return [2, field];
                    }
                });
            });
        };
        FormWithConstraints.prototype.normalizeInputs = function () {
            var _this = this;
            var inputsOrNames = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                inputsOrNames[_i] = arguments[_i];
            }
            var inputs;
            if (inputsOrNames.length === 0) {
                inputs = __spread(this.form.querySelectorAll('[name]'));
                inputs = inputs.filter(function (input) { return input.validity !== undefined; });
                inputs
                    .filter(function (input) { return input.type !== 'checkbox' && input.type !== 'radio'; })
                    .map(function (input) { return input.name; })
                    .forEach(function (name, index, self) {
                    if (self.indexOf(name) !== index) {
                        throw new Error("Multiple elements matching '[name=\"" + name + "\"]' inside the form");
                    }
                });
            }
            else {
                inputs = inputsOrNames.map(function (input) {
                    if (typeof input === 'string') {
                        var query = "[name=\"" + input + "\"]";
                        var elements = __spread(_this.form.querySelectorAll(query));
                        if (elements.filter(function (el) { return el.validity === undefined; }).length > 0) {
                            throw new Error("'" + query + "' should match an <input>, <select> or <textarea>");
                        }
                        if (elements.filter(function (el) { return el.type !== 'checkbox' && el.type !== 'radio'; }).length > 1) {
                            throw new Error("Multiple elements matching '" + query + "' inside the form");
                        }
                        var element = elements[0];
                        if (element === undefined) {
                            throw new Error("Could not find field '" + query + "' inside the form");
                        }
                        return element;
                    }
                    else {
                        return input;
                    }
                });
            }
            return inputs;
        };
        FormWithConstraints.prototype.isValid = function () {
            return this.fieldsStore.isValid();
        };
        FormWithConstraints.prototype.hasFeedbacks = function () {
            return this.fieldsStore.hasFeedbacks();
        };
        FormWithConstraints.prototype.reset = function () {
            return this.resetFields();
        };
        FormWithConstraints.prototype.resetFields = function () {
            var inputsOrNames = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                inputsOrNames[_i] = arguments[_i];
            }
            return __awaiter(this, void 0, void 0, function () {
                var e_2, _a, fields, inputs, inputs_2, inputs_2_1, input, field, e_2_1;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            fields = new Array();
                            inputs = this.normalizeInputs.apply(this, __spread(inputsOrNames));
                            _b.label = 1;
                        case 1:
                            _b.trys.push([1, 6, 7, 8]);
                            inputs_2 = __values(inputs), inputs_2_1 = inputs_2.next();
                            _b.label = 2;
                        case 2:
                            if (!!inputs_2_1.done) return [3, 5];
                            input = inputs_2_1.value;
                            return [4, this.resetField(new InputElement(input))];
                        case 3:
                            field = _b.sent();
                            if (field !== undefined)
                                fields.push(field);
                            _b.label = 4;
                        case 4:
                            inputs_2_1 = inputs_2.next();
                            return [3, 2];
                        case 5: return [3, 8];
                        case 6:
                            e_2_1 = _b.sent();
                            e_2 = { error: e_2_1 };
                            return [3, 8];
                        case 7:
                            try {
                                if (inputs_2_1 && !inputs_2_1.done && (_a = inputs_2.return)) _a.call(inputs_2);
                            }
                            finally { if (e_2) throw e_2.error; }
                            return [7];
                        case 8: return [2, fields];
                    }
                });
            });
        };
        FormWithConstraints.prototype.resetField = function (input) {
            return __awaiter(this, void 0, void 0, function () {
                var fieldName, field;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            fieldName = input.name;
                            field = this.fieldsStore.getField(fieldName);
                            if (!(field === undefined)) return [3, 1];
                            return [3, 3];
                        case 1:
                            field.clearValidations();
                            return [4, this.emitFieldDidResetEvent(field)];
                        case 2:
                            _a.sent();
                            _a.label = 3;
                        case 3: return [2, field];
                    }
                });
            });
        };
        FormWithConstraints.prototype.render = function () {
            var _this = this;
            return React.createElement("form", __assign({ ref: function (form) { return _this.form = form; } }, this.props));
        };
        FormWithConstraints.childContextTypes = {
            form: PropTypes.instanceOf(FormWithConstraints).isRequired
        };
        return FormWithConstraints;
    }(withFieldDidResetEventEmitter(withFieldWillValidateEventEmitter(withFieldDidValidateEventEmitter(withValidateFieldEventEmitter(FormWithConstraintsComponent))))));

    var FieldFeedbacksComponent = (function (_super) {
        __extends(FieldFeedbacksComponent, _super);
        function FieldFeedbacksComponent() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return FieldFeedbacksComponent;
    }(React.Component));
    var FieldFeedbacks = (function (_super) {
        __extends(FieldFeedbacks, _super);
        function FieldFeedbacks(props, context) {
            var _this = _super.call(this, props, context) || this;
            _this.fieldFeedbackKeyCounter = 0;
            _this.validate = function (input) { return __awaiter(_this, void 0, void 0, function () {
                var _a, form, fieldFeedbacksParent, validations, field;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            _a = this.context, form = _a.form, fieldFeedbacksParent = _a.fieldFeedbacks;
                            if (!(input.name === this.fieldName)) return [3, 3];
                            field = form.fieldsStore.getField(this.fieldName);
                            if (!(fieldFeedbacksParent && (fieldFeedbacksParent.props.stop === 'first' && field.hasFeedbacks(fieldFeedbacksParent.key) ||
                                fieldFeedbacksParent.props.stop === 'first-error' && field.hasErrors(fieldFeedbacksParent.key) ||
                                fieldFeedbacksParent.props.stop === 'first-warning' && field.hasWarnings(fieldFeedbacksParent.key) ||
                                fieldFeedbacksParent.props.stop === 'first-info' && field.hasInfos(fieldFeedbacksParent.key)))) return [3, 1];
                            return [3, 3];
                        case 1: return [4, this._validate(input)];
                        case 2:
                            validations = _b.sent();
                            _b.label = 3;
                        case 3: return [2, validations];
                    }
                });
            }); };
            var form = context.form, fieldFeedbacksParent = context.fieldFeedbacks;
            _this.key = fieldFeedbacksParent ? fieldFeedbacksParent.computeFieldFeedbackKey() : form.computeFieldFeedbacksKey();
            if (fieldFeedbacksParent) {
                _this.fieldName = fieldFeedbacksParent.fieldName;
                if (props.for !== undefined)
                    throw new Error("FieldFeedbacks cannot have a parent and a 'for' prop");
            }
            else {
                if (props.for === undefined)
                    throw new Error("FieldFeedbacks cannot be without parent and without 'for' prop");
                else
                    _this.fieldName = props.for;
            }
            return _this;
        }
        FieldFeedbacks.prototype.getChildContext = function () {
            return {
                fieldFeedbacks: this
            };
        };
        FieldFeedbacks.prototype.computeFieldFeedbackKey = function () {
            return this.key + "." + this.fieldFeedbackKeyCounter++;
        };
        FieldFeedbacks.prototype.addFieldFeedback = function () {
            return this.computeFieldFeedbackKey();
        };
        FieldFeedbacks.prototype.componentWillMount = function () {
            var _a = this.context, form = _a.form, fieldFeedbacksParent = _a.fieldFeedbacks;
            form.fieldsStore.addField(this.fieldName);
            var parent = fieldFeedbacksParent ? fieldFeedbacksParent : form;
            parent.addValidateFieldEventListener(this.validate);
        };
        FieldFeedbacks.prototype.componentWillUnmount = function () {
            var _a = this.context, form = _a.form, fieldFeedbacksParent = _a.fieldFeedbacks;
            form.fieldsStore.removeField(this.fieldName);
            var parent = fieldFeedbacksParent ? fieldFeedbacksParent : form;
            parent.removeValidateFieldEventListener(this.validate);
        };
        FieldFeedbacks.prototype._validate = function (input) {
            return __awaiter(this, void 0, void 0, function () {
                var arrayOfArrays, validations;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4, this.emitValidateFieldEvent(input)];
                        case 1:
                            arrayOfArrays = _a.sent();
                            validations = flattenDeep(arrayOfArrays);
                            return [2, validations];
                    }
                });
            });
        };
        FieldFeedbacks.prototype.render = function () {
            var children = this.props.children;
            return children !== undefined ? children : null;
        };
        FieldFeedbacks.defaultProps = {
            stop: 'first-error'
        };
        FieldFeedbacks.contextTypes = {
            form: PropTypes.instanceOf(FormWithConstraints).isRequired,
            fieldFeedbacks: PropTypes.instanceOf(FieldFeedbacks)
        };
        FieldFeedbacks.childContextTypes = {
            fieldFeedbacks: PropTypes.instanceOf(FieldFeedbacks).isRequired
        };
        return FieldFeedbacks;
    }(withValidateFieldEventEmitter(FieldFeedbacksComponent)));

    (function (Status) {
        Status[Status["None"] = 0] = "None";
        Status[Status["Pending"] = 1] = "Pending";
        Status[Status["Rejected"] = 2] = "Rejected";
        Status[Status["Resolved"] = 3] = "Resolved";
    })(exports.Status || (exports.Status = {}));
    var AsyncComponent = (function (_super) {
        __extends(AsyncComponent, _super);
        function AsyncComponent() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return AsyncComponent;
    }(React.Component));
    var Async = (function (_super) {
        __extends(Async, _super);
        function Async() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.state = {
                status: exports.Status.None
            };
            _this.validate = function (input) {
                var _a = _this.context, form = _a.form, fieldFeedbacks = _a.fieldFeedbacks;
                var validations;
                var field = form.fieldsStore.getField(input.name);
                if (fieldFeedbacks.props.stop === 'first' && field.hasFeedbacks(fieldFeedbacks.key) ||
                    fieldFeedbacks.props.stop === 'first-error' && field.hasErrors(fieldFeedbacks.key) ||
                    fieldFeedbacks.props.stop === 'first-warning' && field.hasWarnings(fieldFeedbacks.key) ||
                    fieldFeedbacks.props.stop === 'first-info' && field.hasInfos(fieldFeedbacks.key)) {
                    _this.setState({ status: exports.Status.None });
                }
                else {
                    validations = _this._validate(input);
                }
                return validations;
            };
            return _this;
        }
        Async.prototype.getChildContext = function () {
            return {
                async: this
            };
        };
        Async.prototype.componentWillMount = function () {
            this.context.fieldFeedbacks.addValidateFieldEventListener(this.validate);
        };
        Async.prototype.componentWillUnmount = function () {
            this.context.fieldFeedbacks.removeValidateFieldEventListener(this.validate);
        };
        Async.prototype._validate = function (input) {
            return __awaiter(this, void 0, void 0, function () {
                var value, e_1;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            this.setState({ status: exports.Status.Pending });
                            _a.label = 1;
                        case 1:
                            _a.trys.push([1, 3, , 4]);
                            return [4, this.props.promise(input.value)];
                        case 2:
                            value = _a.sent();
                            this.setState({ status: exports.Status.Resolved, value: value });
                            return [3, 4];
                        case 3:
                            e_1 = _a.sent();
                            this.setState({ status: exports.Status.Rejected, value: e_1 });
                            return [3, 4];
                        case 4: return [2, this.emitValidateFieldEvent(input)];
                    }
                });
            });
        };
        Async.prototype.render = function () {
            var _a = this, props = _a.props, state = _a.state;
            var element = null;
            switch (state.status) {
                case exports.Status.None:
                    break;
                case exports.Status.Pending:
                    if (props.pending)
                        element = props.pending;
                    break;
                case exports.Status.Resolved:
                    if (props.then)
                        element = props.then(state.value);
                    break;
                case exports.Status.Rejected:
                    if (props.catch)
                        element = props.catch(state.value);
                    break;
            }
            return element;
        };
        Async.contextTypes = {
            form: PropTypes.instanceOf(FormWithConstraints).isRequired,
            fieldFeedbacks: PropTypes.instanceOf(FieldFeedbacks).isRequired
        };
        Async.childContextTypes = {
            async: PropTypes.instanceOf(Async).isRequired
        };
        return Async;
    }(withValidateFieldEventEmitter(AsyncComponent)));

    var FieldFeedbackWhenValid = (function (_super) {
        __extends(FieldFeedbackWhenValid, _super);
        function FieldFeedbackWhenValid() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.state = {
                fieldIsValid: undefined
            };
            _this.fieldWillValidate = function (fieldName) {
                if (fieldName === _this.context.fieldFeedbacks.fieldName) {
                    _this.setState({ fieldIsValid: undefined });
                }
            };
            _this.fieldDidValidate = function (field) {
                if (field.name === _this.context.fieldFeedbacks.fieldName) {
                    _this.setState({ fieldIsValid: field.isValid() });
                }
            };
            _this.fieldDidReset = function (field) {
                if (field.name === _this.context.fieldFeedbacks.fieldName) {
                    _this.setState({ fieldIsValid: undefined });
                }
            };
            return _this;
        }
        FieldFeedbackWhenValid.prototype.componentWillMount = function () {
            var form = this.context.form;
            form.addFieldWillValidateEventListener(this.fieldWillValidate);
            form.addFieldDidValidateEventListener(this.fieldDidValidate);
            form.addFieldDidResetEventListener(this.fieldDidReset);
        };
        FieldFeedbackWhenValid.prototype.componentWillUnmount = function () {
            var form = this.context.form;
            form.removeFieldWillValidateEventListener(this.fieldWillValidate);
            form.removeFieldDidValidateEventListener(this.fieldDidValidate);
            form.removeFieldDidResetEventListener(this.fieldDidReset);
        };
        FieldFeedbackWhenValid.prototype.render = function () {
            var _a = this.props, style = _a.style, otherProps = __rest(_a, ["style"]);
            return this.state.fieldIsValid ?
                React.createElement("span", __assign({}, otherProps, { style: __assign({ display: 'block' }, style) }))
                : null;
        };
        FieldFeedbackWhenValid.contextTypes = {
            form: PropTypes.instanceOf(FormWithConstraints).isRequired,
            fieldFeedbacks: PropTypes.instanceOf(FieldFeedbacks).isRequired
        };
        return FieldFeedbackWhenValid;
    }(React.Component));

    var FieldFeedback = (function (_super) {
        __extends(FieldFeedback, _super);
        function FieldFeedback(props, context) {
            var _this = _super.call(this, props, context) || this;
            _this.validate = function (input) {
                var when = _this.props.when;
                var _a = _this.context, form = _a.form, fieldFeedbacks = _a.fieldFeedbacks;
                var field = form.fieldsStore.getField(input.name);
                var validation = __assign({}, _this.state.validation);
                if (fieldFeedbacks.props.stop === 'first' && field.hasFeedbacks(fieldFeedbacks.key) ||
                    fieldFeedbacks.props.stop === 'first-error' && field.hasErrors(fieldFeedbacks.key) ||
                    fieldFeedbacks.props.stop === 'first-warning' && field.hasWarnings(fieldFeedbacks.key) ||
                    fieldFeedbacks.props.stop === 'first-info' && field.hasInfos(fieldFeedbacks.key)) {
                    validation.show = undefined;
                }
                else {
                    validation.show = false;
                    if (typeof when === 'function') {
                        validation.show = when(input.value);
                    }
                    else if (typeof when === 'string') {
                        if (when === 'valid') {
                            validation.show = undefined;
                        }
                        else {
                            var validity = input.validity;
                            if (!validity.valid) {
                                if (when === '*') {
                                    validation.show = true;
                                }
                                else if (validity.badInput && when === 'badInput' ||
                                    validity.patternMismatch && when === 'patternMismatch' ||
                                    validity.rangeOverflow && when === 'rangeOverflow' ||
                                    validity.rangeUnderflow && when === 'rangeUnderflow' ||
                                    validity.stepMismatch && when === 'stepMismatch' ||
                                    validity.tooLong && when === 'tooLong' ||
                                    validity.tooShort && when === 'tooShort' ||
                                    validity.typeMismatch && when === 'typeMismatch' ||
                                    validity.valueMissing && when === 'valueMissing') {
                                    validation.show = true;
                                }
                            }
                        }
                    }
                    else {
                        throw new TypeError("Invalid FieldFeedback 'when' type: " + typeof when);
                    }
                }
                field.addOrReplaceValidation(validation);
                _this.setState({
                    validation: validation,
                    validationMessage: input.validationMessage
                });
                return validation;
            };
            _this.fieldDidReset = function (field) {
                if (field.name === _this.context.fieldFeedbacks.fieldName) {
                    _this.setState(function (prevState) { return ({
                        validation: __assign({}, prevState.validation, { show: undefined }),
                        validationMessage: ''
                    }); });
                }
            };
            _this.key = context.fieldFeedbacks.addFieldFeedback();
            var error = props.error, warning = props.warning, info = props.info, when = props.when;
            var type = FieldFeedbackType$1.Error;
            if (when === 'valid')
                type = FieldFeedbackType$1.WhenValid;
            else if (warning)
                type = FieldFeedbackType$1.Warning;
            else if (info)
                type = FieldFeedbackType$1.Info;
            if (type === FieldFeedbackType$1.WhenValid && (error || warning || info)) {
                throw new Error('Cannot have an attribute (error, warning...) with FieldFeedback when="valid"');
            }
            _this.state = {
                validation: {
                    key: _this.key,
                    type: type,
                    show: undefined
                },
                validationMessage: ''
            };
            return _this;
        }
        FieldFeedback.prototype.componentWillMount = function () {
            var _a = this.context, form = _a.form, fieldFeedbacks = _a.fieldFeedbacks, async = _a.async;
            if (async)
                async.addValidateFieldEventListener(this.validate);
            else
                fieldFeedbacks.addValidateFieldEventListener(this.validate);
            form.addFieldDidResetEventListener(this.fieldDidReset);
        };
        FieldFeedback.prototype.componentWillUnmount = function () {
            var _a = this.context, form = _a.form, fieldFeedbacks = _a.fieldFeedbacks, async = _a.async;
            if (async)
                async.removeValidateFieldEventListener(this.validate);
            else
                fieldFeedbacks.removeValidateFieldEventListener(this.validate);
            form.removeFieldDidResetEventListener(this.fieldDidReset);
        };
        FieldFeedback.prototype.render = function () {
            var _a = this.props, when = _a.when, error = _a.error, warning = _a.warning, info = _a.info, className = _a.className, classes = _a.classes, style = _a.style, children = _a.children, otherProps = __rest(_a, ["when", "error", "warning", "info", "className", "classes", "style", "children"]);
            var _b = this.state, validation = _b.validation, validationMessage = _b.validationMessage;
            var fieldFeedbackClassName = classes[validation.type];
            var classNames = className !== undefined ? className + " " + fieldFeedbackClassName : fieldFeedbackClassName;
            if (validation.type === FieldFeedbackType$1.WhenValid) {
                return React.createElement(FieldFeedbackWhenValid, __assign({ "data-feedback": this.key, style: style, className: classNames }, otherProps), children);
            }
            if (validation.show) {
                var feedback = children !== undefined ? children : validationMessage;
                return React.createElement("span", __assign({ "data-feedback": this.key, className: classNames, style: __assign({ display: 'block' }, style) }, otherProps), feedback);
            }
            return null;
        };
        FieldFeedback.defaultProps = {
            when: function () { return true; },
            classes: {
                error: 'error',
                warning: 'warning',
                info: 'info',
                whenValid: 'when-valid'
            }
        };
        FieldFeedback.contextTypes = {
            form: PropTypes.instanceOf(FormWithConstraints).isRequired,
            fieldFeedbacks: PropTypes.instanceOf(FieldFeedbacks).isRequired,
            async: PropTypes.instanceOf(Async)
        };
        return FieldFeedback;
    }(React.Component));

    var Input = (function (_super) {
        __extends(Input, _super);
        function Input() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.state = {
                field: undefined
            };
            _this.fieldWillValidate = function (fieldName) {
                if (fieldName === _this.props.name) {
                    _this.setState({ field: 'pending' });
                }
            };
            _this.fieldDidValidate = function (field) {
                if (field.name === _this.props.name) {
                    _this.setState({ field: field });
                }
            };
            _this.fieldDidReset = function (field) {
                if (field.name === _this.props.name) {
                    _this.setState({ field: undefined });
                }
            };
            return _this;
        }
        Input.prototype.componentWillMount = function () {
            this.context.form.addFieldWillValidateEventListener(this.fieldWillValidate);
            this.context.form.addFieldDidValidateEventListener(this.fieldDidValidate);
            this.context.form.addFieldDidResetEventListener(this.fieldDidReset);
        };
        Input.prototype.componentWillUnmount = function () {
            this.context.form.removeFieldWillValidateEventListener(this.fieldWillValidate);
            this.context.form.removeFieldDidValidateEventListener(this.fieldDidValidate);
            this.context.form.removeFieldDidResetEventListener(this.fieldDidReset);
        };
        Input.prototype.fieldValidationStates = function () {
            var field = this.state.field;
            var states = [];
            if (field !== undefined) {
                if (field === 'pending') {
                    states.push('isPending');
                }
                else {
                    if (field.hasErrors())
                        states.push('hasErrors');
                    if (field.hasWarnings())
                        states.push('hasWarnings');
                    if (field.hasInfos())
                        states.push('hasInfos');
                    if (field.isValid())
                        states.push('isValid');
                }
            }
            return states;
        };
        Input.prototype.render = function () {
            var _a = this.props, innerRef = _a.innerRef, className = _a.className, classes = _a.classes, inputProps = __rest(_a, ["innerRef", "className", "classes"]);
            var validationStates = this.fieldValidationStates();
            var classNames = className;
            validationStates.forEach(function (validationState) {
                var tmp = classes[validationState];
                if (tmp !== undefined) {
                    classNames !== undefined ? classNames += " " + tmp : classNames = tmp;
                }
            });
            return (React.createElement("input", __assign({ ref: innerRef }, inputProps, { className: classNames })));
        };
        Input.contextTypes = {
            form: PropTypes.instanceOf(FormWithConstraints).isRequired
        };
        Input.defaultProps = {
            classes: {
                isPending: 'is-pending',
                hasErrors: 'has-errors',
                hasWarnings: 'has-warnings',
                hasInfos: 'has-infos',
                isValid: 'is-valid'
            }
        };
        return Input;
    }(React.Component));

    var deepForEach = function (children, fn) {
        React.Children.forEach(children, function (child) {
            var element = child;
            if (element.props && element.props.children && typeof element.props.children === 'object') {
                deepForEach(element.props.children, fn);
            }
            fn(element);
        });
    };

    exports.FieldFeedbackType = FieldFeedbackType$1;
    exports.Field = Field;
    exports.EventEmitter = EventEmitter;
    exports.deepForEach = deepForEach;
    exports.FormWithConstraints = FormWithConstraints;
    exports.FieldFeedbacks = FieldFeedbacks;
    exports.FieldFeedback = FieldFeedback;
    exports.FieldFeedbackWhenValid = FieldFeedbackWhenValid;
    exports.Async = Async;
    exports.FieldsStore = FieldsStore;
    exports.ValidateFieldEvent = ValidateFieldEvent;
    exports.withValidateFieldEventEmitter = withValidateFieldEventEmitter;
    exports.FieldWillValidateEvent = FieldWillValidateEvent;
    exports.withFieldWillValidateEventEmitter = withFieldWillValidateEventEmitter;
    exports.FieldDidValidateEvent = FieldDidValidateEvent;
    exports.withFieldDidValidateEventEmitter = withFieldDidValidateEventEmitter;
    exports.FieldDidResetEvent = FieldDidResetEvent;
    exports.withFieldDidResetEventEmitter = withFieldDidResetEventEmitter;
    exports.InputElement = InputElement;
    exports.IValidityState = IValidityState;
    exports.Input = Input;

    Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=react-form-with-constraints.development.js.map
